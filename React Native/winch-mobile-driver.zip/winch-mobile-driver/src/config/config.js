export const ApiConfig = {
  baseUrl: "http://3.15.45.186:4000/v1/",
};
