import React from "react";
import {
  CreditCardInput,
  LiteCreditCardInput,
} from "react-native-credit-card-input";
import { Block, Checkbox, Text, theme } from "galio-framework";
import {
  StyleSheet,
  ImageBackground,
  Dimensions,
  StatusBar,
  KeyboardAvoidingView,
} from "react-native";

class PaymentCard extends React.Component {
  render() {
    (_onChange) => (form) => console.log(form);
    return (
      <Block flex middle>
        <Block style={styles.paymentCardContainer}>
          <CreditCardInput />
        </Block>
      </Block>
    );
  }
}

const styles = StyleSheet.create({
  paymentCardContainer: {
    marginTop: 30,
  },
});

export default PaymentCard;
