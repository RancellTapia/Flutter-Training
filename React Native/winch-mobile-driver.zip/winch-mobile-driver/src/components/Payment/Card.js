import React from "react";
import { withNavigation } from "@react-navigation/compat";
import { StyleSheet, SafeAreaView, View, Text } from "react-native";
import { theme, Input } from "galio-framework";

import { Card } from "galio-framework";

function CardPayment(props) {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.containerView}>
        <View  style={{ flex: 0.8, marginRight: 10 }}>
          <Input color={theme.COLORS.WHITE} placeholderTextColor="#ffffff" style={styles.input} type="number-pad" placeholder="Card Number" value={props.card.cardNumber} />
        </View>
        <View style={{ flex: 0.4 }}>
          <Input color={theme.COLORS.WHITE} style={styles.input} placeholderTextColor="#ffffff" placeholder="Expires" value={props.card.expires}  />
        </View>
      </View>
      <View style={styles.containerView}>
        <View style={{ flex: 0.8, marginRight: 10 }}>
          <Input color={theme.COLORS.WHITE} style={styles.input} placeholder="Name" placeholderTextColor="#ffffff" value={props.card.name} />
        </View>
        <View style={{ flex: 0.4 }}>
          <Input color={theme.COLORS.WHITE} style={styles.input} type="number-pad" placeholder="CVC" placeholderTextColor="#ffffff" value={props.card.cvc}  />
        </View>
      </View>
    </SafeAreaView>
  );
}


const styles = StyleSheet.create({
  container: {
    marginTop: 20,
    marginHorizontal: 15,
    backgroundColor: "#78849E",
    borderRadius: 12,
  },
  containerView: {
    flexDirection: "row",
    height: 100,
    padding: 20,
  },
  input: {
    backgroundColor: "#454F63"
  }
});

export default CardPayment;
