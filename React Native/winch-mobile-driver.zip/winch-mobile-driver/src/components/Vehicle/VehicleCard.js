import React from "react";
import { withNavigation } from "@react-navigation/compat";
import {
  StyleSheet,
  SafeAreaView,
  View,
  Text,
  ImageBackground,
} from "react-native";
import { theme, Input } from "galio-framework";

import { Card } from "galio-framework";
import Images from "../../constants/Images";

function VehicleCard(props){
  return (
    <SafeAreaView style={styles.container}>
      <View>
          <Card
            flex
            borderless
            style={styles.card}
            title={`${props.vehicle.brand} ${props.vehicle.model}`}
            caption={props.vehicle.year}
            imageBlockStyle={{ padding: theme.SIZES.BASE / 3 }}
            image="https://www.jaguarusa.com/sdlmedia/637045972570899010KK.jpg?v=1#desktop__1600x900"
            imageStyle={{height: 150}}
            titleColor="white"
          />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 20,
    marginHorizontal: 15,
    backgroundColor: "#2A2E43",
    borderRadius: 5
  },
  image: {
    flex: 1,
    height: 190,
  },
  card: {

  }
});

export default VehicleCard;
