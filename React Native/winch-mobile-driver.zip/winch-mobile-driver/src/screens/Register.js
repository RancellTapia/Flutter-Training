import React, {useState} from "react";
import {
  StyleSheet,
  ImageBackground,
  Dimensions,
  StatusBar,
  KeyboardAvoidingView,
} from "react-native";
import { Block, Checkbox, Text, theme } from "galio-framework";

import { Button, Icon, Input } from "../components";
import { Images, argonTheme } from "../constants";
import Spinner from "react-native-loading-spinner-overlay";
import API, { setClientToken, StoreData } from "../Api/Api";

const { width, height } = Dimensions.get("screen");

function Register(props) {
  const { navigation } = props;
  const [user, setUser] = useState({
    name: "",
    lastname: "",
    username: "",
    email: "",
    password: "",
    role: "client",
    errors: {},
    isAuthorized: false,
    isLoading: false,
  });

  function onPressRegister() {
    const { email, password,name, lastname, username, role } = user;
    const payload = { email, password, name ,lastname, username, role};
    setUser({ ...user, isLoading: true });
    const onSuccess = ({ data }) => {
      const value = data.data;
      const token = value.tokens.accessToken;
      const refreshToken = value.tokens.refreshToken;
      const user = value.user;
      const result = { token, refreshToken, user };

      StoreData(result);
      setClientToken(token);
      setUser({ ...user, isLoading: false, isAuthorized: true });

      navigation.navigate("App");
    };

    const onFailure = (error) => {
      console.log(error.response);
      setUser({ ...user, errors: error.response.data, isLoading: false });
    };

     API.post("user/register", payload).then(onSuccess).catch(onFailure);
  }
  return (
    <Block flex middle>
      <Spinner visible={user.isLoading} />
      <StatusBar hidden />
      <ImageBackground
        source={Images.RegisterBackground}
        style={{ width, height, zIndex: 1 }}
      >
        <Block flex middle>
          <Block style={styles.registerContainer}>
            <Block flex={0.25} middle style={styles.socialConnect}>
              <Text color="#8898AA" size={12}>
                Sign Up
              </Text>
              <Block row style={{ marginTop: theme.SIZES.BASE }}>
                <Button
                  onPress={() => navigation.navigate("Login")}
                  style={{ ...styles.socialButtons, marginRight: 30 }}
                >
                  <Block row>
                    <Text style={styles.socialTextButtons}>Login</Text>
                  </Block>
                </Button>
                <Button style={styles.socialButtonsRegister}>
                  <Block row>
                    <Text style={styles.socialTextButtons}>Sign Up</Text>
                  </Block>
                </Button>
              </Block>
            </Block>
            <Block flex>
              <Block flex center>
                <KeyboardAvoidingView
                  style={{ flex: 1 }}
                  behavior="padding"
                  enabled
                >
                  <Block width={width * 0.8} style={{ marginBottom: 15 }}>
                    <Input
                      borderless
                      placeholder="Name"
                      name="name"
                      value={user.name}
                      onChangeText={(value) => setUser({...user, name: value })}
                      iconContent={
                        <Icon
                          size={16}
                          color={argonTheme.COLORS.ICON}
                          name="hat-3"
                          family="ArgonExtra"
                          style={styles.inputIcons}
                        />
                      }
                    />
                  </Block>
                  <Block width={width * 0.8} style={{ marginBottom: 15 }}>
                    <Input
                      borderless
                      placeholder="LastName"
                      name="lastname"
                      value={user.lastname}
                      onChangeText={(value) => setUser({...user, lastname: value })}
                      iconContent={
                        <Icon
                          size={16}
                          color={argonTheme.COLORS.ICON}
                          name="hat-3"
                          family="ArgonExtra"
                          style={styles.inputIcons}
                        />
                      }
                    />
                  </Block>
                  <Block width={width * 0.8} style={{ marginBottom: 15 }}>
                    <Input
                      borderless
                      placeholder="UserName"
                      name="username"
                      value={user.username}
                      onChangeText={(value) => setUser({...user, username: value })}
                      iconContent={
                        <Icon
                          size={16}
                          color={argonTheme.COLORS.ICON}
                          name="hat-3"
                          family="ArgonExtra"
                          style={styles.inputIcons}
                        />
                      }
                    />
                  </Block>
                  <Block width={width * 0.8} style={{ marginBottom: 15 }}>
                    <Input
                      borderless
                      placeholder="Email"
                      name="email"
                      value={user.email}
                      onChangeText={(value) => setUser({...user, email: value })}
                      iconContent={
                        <Icon
                          size={16}
                          color={argonTheme.COLORS.ICON}
                          name="ic_mail_24px"
                          family="ArgonExtra"
                          style={styles.inputIcons}
                        />
                      }
                    />
                  </Block>
                  <Block width={width * 0.8}>
                    <Input
                      password
                      borderless
                      placeholder="Password"
                      name="password"
                      value={user.password}
                      onChangeText={(value) => setUser({...user, password: value })}
                      iconContent={
                        <Icon
                          size={16}
                          color={argonTheme.COLORS.ICON}
                          family="ArgonExtra"
                          name="padlock-unlocked"
                          style={styles.inputIcons}
                        />
                      }
                    />
                  </Block>
                  <Block row width={width * 0.75}>
                    <Checkbox
                      checkboxStyle={{
                        borderWidth: 3,
                      }}
                      color={argonTheme.COLORS.PRIMARY}
                      label="I agree with the"
                    />
                    <Button
                      style={{ width: 100 }}
                      color="transparent"
                      textStyle={{
                        color: argonTheme.COLORS.PRIMARY,
                        fontSize: 14,
                      }}
                    >
                      Privacy Policy
                    </Button>
                  </Block>
                  <Block middle>
                    <Button
                      onPress={onPressRegister}
                      color="primary"
                      style={styles.createButton}
                    >
                      <Text bold size={14} color={argonTheme.COLORS.WHITE}>
                        CREATE ACCOUNT
                      </Text>
                    </Button>
                  </Block>
                </KeyboardAvoidingView>
              </Block>
            </Block>
          </Block>
        </Block>
      </ImageBackground>
    </Block>
  );
}

const styles = StyleSheet.create({
  registerContainer: {
    width: width * 0.9,
    height: height * 0.85,
    backgroundColor: "#F4F5F7",
    borderRadius: 4,
    shadowColor: argonTheme.COLORS.BLACK,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 8,
    shadowOpacity: 0.1,
    elevation: 1,
    overflow: "hidden",
  },
  socialConnect: {
    backgroundColor: argonTheme.COLORS.WHITE,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: "#8898AA",
  },
  socialButtonsRegister: {
    width: 120,
    height: 40,
    backgroundColor: "#fff",
    shadowColor: argonTheme.COLORS.BLACK,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 8,
    shadowOpacity: 0.1,
    elevation: 1,
    borderBottomWidth: 5,
    borderBottomColor: argonTheme.COLORS.PRIMARY,
  },
  socialButtons: {
    width: 120,
    height: 40,
    backgroundColor: "#fff",
    shadowColor: argonTheme.COLORS.BLACK,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 8,
    shadowOpacity: 0.1,
    elevation: 1,
  },
  socialTextButtons: {
    color: argonTheme.COLORS.PRIMARY,
    fontWeight: "800",
    fontSize: 14,
  },
  inputIcons: {
    marginRight: 12,
  },
  passwordCheck: {
    paddingLeft: 15,
    paddingTop: 13,
    paddingBottom: 30,
  },
  createButton: {
    width: width * 0.5,
    marginTop: 25,
  },
});

export default Register;
