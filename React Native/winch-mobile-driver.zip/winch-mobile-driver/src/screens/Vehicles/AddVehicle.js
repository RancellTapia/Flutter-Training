import React, {useState} from "react";
import {
  ScrollView,
  StyleSheet,
  Dimensions,
  View,
  SafeAreaView,
  Alert 
} from "react-native";
//galio
import { Block, Text, theme } from "galio-framework";
import { Images, argonTheme } from "../../constants";
import { Button, Icon, Input } from "../../components";

import PaymentCard from "../../components/Payment/PaymentCard";
import API from "../../Api/Api";
import Spinner from "react-native-loading-spinner-overlay";

const { width } = Dimensions.get("screen");

function AddVehicle(props) {
  const { navigation } = props;
  const [vehicle, setVehicle] = useState({
    brandName: "",
    modelName: "",
    color: "",
    year: "",
    registrationPlate: "",
    errors: {},
    isAuthorized: false,
    isLoading: false,
  });

  function onPressAdd() {
    const { brandName, modelName,color, year, registrationPlate } = vehicle;
    const payload = { brandName, modelName, color ,registrationPlate, year};
    setVehicle({ ...vehicle, isLoading: true });
    const onSuccess = ({ data }) => {
      Alert.alert('Registry', 'Added Correctly', [{text: 'OK', onPress: () => {
        setVehicle({ ...vehicle, isLoading: false, isAuthorized: true });
        navigation.navigate("Vehicles");
      }}]);
      
    };
    const onFailure = (error) => {
      Alert.alert('Registry', 'not added, try again', [{text: 'OK', onPress: () => {
        setVehicle({ ...vehicle, isLoading: false, isAuthorized: false });
      }}]);
      console.log(error.response);
    };
     API.post("client/vehicles", payload).then(onSuccess).catch(onFailure);
  }

  return (
    <SafeAreaView style={styles.container}>
    <Spinner visible={vehicle.isLoading} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <Text style={{ fontSize: 40, marginTop: 15, marginLeft: 13 }}>
          Vehicle
        </Text>
        <Block flex>
        <Block  flex center >
          <Block width={width * 0.9} style={{ marginBottom: 15 }}>
            <Input
              placeholder="Brand"
              borderless
              name="brandName"
              value={vehicle.name}
              onChangeText={(value) => setVehicle({ ...vehicle, brandName: value })}
              iconContent={
                <Icon
                  size={16}
                  color={argonTheme.COLORS.ICON}
                  name="hat-3"
                  family="ArgonExtra"
                  style={styles.inputIcons}
                />
              }
            />
          </Block>

          <Block width={width * 0.9} style={{ marginBottom: 15 }}>
            <Input
              placeholder="Model"
              borderless
              name="modelName"
              value={vehicle.name}
              onChangeText={(value) => setVehicle({ ...vehicle, modelName: value })}
              iconContent={
                <Icon
                  size={16}
                  color={argonTheme.COLORS.ICON}
                  name="hat-3"
                  family="ArgonExtra"
                  style={styles.inputIcons}
                />
              }
            />
          </Block>

          <Block width={width * 0.9} style={{ marginBottom: 15 }}>
            <Input
              borderless
              placeholder="Year"
              name="year"
              value={vehicle.name}
              onChangeText={(value) => setVehicle({ ...vehicle, year: value })}
              iconContent={
                <Icon
                  size={16}
                  color={argonTheme.COLORS.ICON}
                  name="hat-3"
                  family="ArgonExtra"
                  style={styles.inputIcons}
                />
              }
            />
          </Block>

          <Block width={width * 0.9} style={{ marginBottom: 15 }}>
            <Input
              borderless
              placeholder="Color"
              name="color"
              value={vehicle.name}
              onChangeText={(value) => setVehicle({ ...vehicle, color: value })}
              iconContent={
                <Icon
                  size={16}
                  color={argonTheme.COLORS.ICON}
                  name="hat-3"
                  family="ArgonExtra"
                  style={styles.inputIcons}
                />
              }
            />
          </Block>

          <Block width={width * 0.9} style={{ marginBottom: 15 }}>
            <Input
              borderless
              placeholder="Plate"
              name="registrationPlate"
              value={vehicle.registrationPlate}
              onChangeText={(value) => setVehicle({ ...vehicle, registrationPlate: value })}
              iconContent={
                <Icon
                  size={16}
                  color={argonTheme.COLORS.ICON}
                  name="hat-3"
                  family="ArgonExtra"
                  style={styles.inputIcons}
                />
              }
            />
          </Block>

          <Block middle>
            <Button
              onPress={onPressAdd}
              color="primary"
              style={styles.createButton}
            >
              <Text bold size={14} color={argonTheme.COLORS.WHITE}>
                CREATE
              </Text>
            </Button>
          </Block>
        </Block>
        </Block>
        
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  containerView: {
    flexDirection: "row",
    height: 100,
    padding: 20,
  },
  contentInput: {
    padding: 15,
  },
  contentButton: {
    flexDirection: "row",
    height: 100,
    padding: 20,
  },
  button: {
    color: "black",
  },
  container: {
    flex: 1,
  },
  input: {
    borderRadius: 10,
    height: 60,
  },
  createButton: {
    width: width * 0.5,
    marginTop: 25,
  },
  inputIcons: {
    marginRight: 12,
  },
});

export default AddVehicle;
