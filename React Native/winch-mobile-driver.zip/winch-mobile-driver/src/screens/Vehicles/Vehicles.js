import React from "react";
import {
  ScrollView,
  StyleSheet,
  Dimensions,
  View,
  SafeAreaView,
} from "react-native";
// Galio components
import { Block, Text, theme, Button, Input } from "galio-framework";
// Argon themed components
import { argonTheme } from "../../constants";
import VehicleCard from "../../components/Vehicle/VehicleCard";
const { width } = Dimensions.get("screen");

class Vehicles extends React.Component {
  vehicles = [];
  render() {
    this.vehicles.push(
      {
        brand: 'Honda',
        model: 'Civil',
        year: '2017'
      }
    )
    const { navigation } = this.props;
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView showsVerticalScrollIndicator={false}>
            <View style={styles.contentButton}>
            <Button
              onPress={() => navigation.navigate("AddVehicle")}
              onlyIcon
              icon="plus"
              iconFamily="antdesign"
              iconSize={30}
              color="success"
              iconColor="#fff"
              style={{ width: 40, height: 40 }}
            ></Button>
          </View>
          <View>
          {
           this.vehicles.map((vehicle , key) => {
            return <VehicleCard key={key} vehicle={vehicle} />
           })
          }
            
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  contentInput: {
    padding: 15,
  },
  contentButton: {
    alignItems: "flex-end",
    marginEnd: 15,
    marginTop: 20,
  },
  container: {
    flex: 1,
  },
});

export default Vehicles;
