import React from 'react';
import { StyleSheet, Dimensions, View } from 'react-native';
// Galio components
import { Block, Text } from 'galio-framework';
// Argon themed components
import { argonTheme } from '../../../constants';
const { width } = Dimensions.get('screen');
const circle = 10;
const miniCircle = 4;

const CardHistory = (props) => {
	return (
		<Block style={{ marginHorizontal: '6%', marginTop: 25 }}>
			<Text style={styles.label}>JAN 10 - 12:30 PM</Text>
			<Block card style={styles.card}>
				<View style={styles.groupCircle}>
					<View style={styles.circle} />
					<View style={styles.miniCircle} />
					<View style={styles.miniCircle} />
					<View style={styles.miniCircle} />
					<View style={styles.miniCircle} />
					<View style={styles.circle} />
				</View>
				<View style={{ marginTop: 20 }}>
					<Text style={styles.cardLabel}>Pickup Location</Text>
					<Text style={styles.cardText}>Fresh Market </Text>
					<View style={styles.line} />
					<Text style={styles.cardLabel}>Destination Location</Text>
					<Text style={styles.cardText}>My Home</Text>
				</View>
			</Block>
		</Block>
	);
};

const styles = StyleSheet.create({
	card: {
		height: 195,
		backgroundColor: '#FFF',
		marginTop: 12,
		elevation: 1,
		flexDirection: 'row',
	},
	cardLabel: {
		fontSize: 16,
		color: argonTheme.COLORS.PLACEHOLDER,
	},
	cardText: {
		fontSize: 24,
		color: argonTheme.COLORS.HEADER,
		marginTop: 2,
	},
	label: {
		color: argonTheme.COLORS.PLACEHOLDER,
		fontSize: 14,
	},
	groupCircle: {
		flexDirection: 'column',
		width: 40,
		height: 100,
		alignItems: 'center',
		justifyContent: 'space-between',
		marginTop: 28,
		marginHorizontal: 20,
	},
	circle: {
		width: circle,
		height: circle,
		borderRadius: circle / 2,
		backgroundColor: argonTheme.COLORS.HEADER,
	},
	miniCircle: {
		width: miniCircle,
		height: miniCircle,
		borderRadius: miniCircle / 2,
		backgroundColor: argonTheme.COLORS.PLACEHOLDER,
	},
	line: {
		width: width * 0.62,
		height: 1,
		backgroundColor: argonTheme.COLORS.PLACEHOLDER,
		marginVertical: 21,
	},
});

export default CardHistory;
