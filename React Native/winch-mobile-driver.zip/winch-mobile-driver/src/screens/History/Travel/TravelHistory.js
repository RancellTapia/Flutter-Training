import React from 'react';
import {
	ScrollView,
	StyleSheet,
	Dimensions,
	View,
	SafeAreaView,
} from 'react-native';
// Galio components
import { Block, Text, theme, Button, Input } from 'galio-framework';
// Argon themed components
import { argonTheme } from '../../../constants';
import CardHistory from './CardHistory';

const { width, height } = Dimensions.get('screen');

const TravelHistory = ({ setViewHistory }) => {
	return (
		<Block>
			<Block row style={{ marginTop: 10 }}>
				<Button style={styles.activeButton}>
					<Block row>
						<Text style={styles.TextButtons}>History</Text>
					</Block>
				</Button>
				<Button
					style={styles.inactiveButton}
					onPress={() => setViewHistory('Payment')}
				>
					<Block row>
						<Text style={styles.TextButtons}>Payment History</Text>
					</Block>
				</Button>
			</Block>
			<ScrollView>
				<CardHistory />
				<CardHistory />
				<CardHistory />
				<CardHistory />
				<CardHistory />
			</ScrollView>
		</Block>
	);
};

const styles = StyleSheet.create({
	contentInput: {
		padding: 15,
	},
	container: {
		flex: 1,
	},
	activeButton: {
		width: width / 2,
		height: 50,
		backgroundColor: '#fff',
		shadowColor: argonTheme.COLORS.BLACK,
		shadowOffset: {
			width: 0,
			height: 4,
		},
		shadowRadius: 8,
		shadowOpacity: 0.1,
		elevation: 1,
		borderBottomWidth: 5,
		borderBottomColor: argonTheme.COLORS.PRIMARY,
	},
	inactiveButton: {
		width: width / 2,
		height: 50,
		backgroundColor: '#fff',
		shadowColor: argonTheme.COLORS.BLACK,
		shadowOffset: {
			width: 0,
			height: 4,
		},
		shadowRadius: 8,
		shadowOpacity: 0.1,
		elevation: 1,
	},
	TextButtons: {
		color: argonTheme.COLORS.PLACEHOLDER,
		fontWeight: '800',
		fontSize: 14,
	},
});

export default TravelHistory;
