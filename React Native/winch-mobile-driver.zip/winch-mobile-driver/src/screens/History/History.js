import React, { useState } from 'react';

// Galio components
import { Block } from 'galio-framework';

import TravelHistory from './Travel/TravelHistory';
import PaymentHistory from './Payment/PaymentHistory';

const History = (props) => {
	const [viewHistory, setViewHistory] = useState('Travel');
	return (
		<Block>
			{viewHistory === 'Travel' ? (
				<TravelHistory setViewHistory={setViewHistory} />
			) : (
				<PaymentHistory setViewHistory={setViewHistory} />
			)}
		</Block>
	);
};

export default History;
