import React from 'react';
import { StyleSheet, Dimensions, View } from 'react-native';
import { AntDesign, FontAwesome } from '@expo/vector-icons';
// Galio components
import { Block, Text } from 'galio-framework';
// Argon themed components
import { argonTheme } from '../../../constants';
const { width } = Dimensions.get('screen');

const CardPaymentDetails = (props) => {
	return (
		<Block style={{ marginHorizontal: '6%', marginTop: 25 }}>
			<Block card style={styles.card}>
				<Block style={[styles.container, { marginTop: 30 }]}>
					<Block style={{ flexDirection: 'row' }}>
						<View style={styles.circle} />
						<Text style={styles.cardText}>Profits</Text>
					</Block>
					<Block
						style={{
							justifyContent: 'center',
						}}
					>
						<Text style={styles.cardLabel}>80,000</Text>
					</Block>
				</Block>
				<View style={styles.line} />
				<Block style={styles.container}>
					<Block style={{ flexDirection: 'row' }}>
						<View style={styles.circle} />
						<Text style={styles.cardText}>Distance traveled</Text>
					</Block>
					<Block
						style={{
							justifyContent: 'center',
						}}
					>
						<Text style={styles.cardLabel}>176 km</Text>
					</Block>
				</Block>
				<View style={styles.line} />
				<Block style={styles.container}>
					<Block style={{ flexDirection: 'row' }}>
						<View style={styles.circle} />
						<Text style={styles.cardText}>Interests</Text>
					</Block>
					<Block
						style={{
							justifyContent: 'center',
						}}
					>
						<Text style={styles.cardLabel}>5,346</Text>
					</Block>
				</Block>
				<View style={styles.line} />
				<Block style={styles.container}>
					<Block style={{ flexDirection: 'row' }}>
						<View style={styles.circle} />
						<Text style={styles.cardText}>Total</Text>
					</Block>
					<Block
						style={{
							justifyContent: 'center',
						}}
					>
						<Text style={styles.cardLabel}>85,346</Text>
					</Block>
				</Block>
			</Block>
		</Block>
	);
};

const styles = StyleSheet.create({
	card: {
		height: 280,
		backgroundColor: '#FFF',
		flexDirection: 'column',
		alignItems: 'center',
	},
	container: {
		marginHorizontal: 30,
		flexDirection: 'row',
		width: width * 0.75,
		height: 40,
		justifyContent: 'space-between',
	},
	cardLabel: {
		fontSize: 18,
		color: argonTheme.COLORS.PLACEHOLDER,
	},
	cardText: {
		fontSize: 20,
		color: argonTheme.COLORS.HEADER,
		alignSelf: 'center',
	},
	circle: {
		width: 12,
		height: 12,
		borderRadius: 6 / 2,
		backgroundColor: '#3497FD',
		marginRight: 20,
		alignSelf: 'center',
	},
	line: {
		width: width * 0.75,
		height: 1,
		backgroundColor: argonTheme.COLORS.PLACEHOLDER,
		marginVertical: 10,
	},
});

export default CardPaymentDetails;
