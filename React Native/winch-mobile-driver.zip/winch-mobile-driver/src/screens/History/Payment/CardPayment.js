import React from 'react';
import { StyleSheet, Dimensions, View } from 'react-native';
import { AntDesign, FontAwesome } from '@expo/vector-icons';
// Galio components
import { Block, Text } from 'galio-framework';
// Argon themed components
import { argonTheme } from '../../../constants';
const { width } = Dimensions.get('screen');

const CardPayment = (props) => {
	return (
		<Block style={{ marginHorizontal: '6%', marginTop: 25 }}>
			<Block card style={styles.card}>
				<Block style={styles.container}>
					<Block style={{ justifyContent: 'center' }}>
						<Text style={styles.cardText}>$48,000</Text>
						<Text style={styles.cardLabel}>15/06/2020</Text>
					</Block>
					<Block
						style={{
							justifyContent: 'center',
						}}
					>
						<AntDesign name='down' size={24} color='black' />
					</Block>
				</Block>
			</Block>
		</Block>
	);
};

const styles = StyleSheet.create({
	card: {
		height: 105,
		backgroundColor: '#FFF',
		flexDirection: 'row',
	},
	container: {
		marginHorizontal: 30,
		flexDirection: 'row',
		width: width * 0.75,
		justifyContent: 'space-between',
	},
	cardLabel: {
		fontSize: 18,
		color: argonTheme.COLORS.PLACEHOLDER,
	},
	cardText: {
		fontSize: 32,
		color: argonTheme.COLORS.HEADER,
		marginTop: 2,
	},
});

export default CardPayment;
