import React from "react";
import {
  ScrollView,
  StyleSheet,
  Dimensions,
  View,
  SafeAreaView,
} from "react-native";
//galio
import { Block, Text, theme, Button, Input } from "galio-framework";
//argon
import { Images, argonTheme } from "../../constants";

const { width } = Dimensions.get("screen");

const thumbMeasure = (width - 48 - 32) / 3;
const cardWidth = width - theme.SIZES.BASE * 2;
import CardPayment from "../../components/Payment/Card";
class Payments extends React.Component {
  cards = [];

  render() {
    this.cards.push({
      cardNumber: '4545-4545-4545-5478',
      expires: '02/24',
      name: "joe patines",
      cvc: '241',
    },
    {
      cardNumber: '8448-4154-8415-4884',
      expires: '02/24',
      name: "joe patines",
      cvc: '458',
    });
    const { navigation } = this.props;

    return (
      <SafeAreaView style={styles.container}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.contentButton}>
            <Button
              onPress={() => navigation.navigate("AddPayment")}
              onlyIcon
              icon="plus"
              iconFamily="antdesign"
              iconSize={30}
              color="success"
              iconColor="#fff"
              style={{ width: 40, height: 40 }}
            ></Button>
          </View>
          <View>
            {this.cards.map((card) => {
              return (<CardPayment key={card.cardNumber} card={card} />)
            })}
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }
}
const styles = StyleSheet.create({
  contentInput: {
    padding: 15,
  },
  contentButton: {
    alignItems: "flex-end",
    marginEnd: 15,
    marginTop: 20,
  },
  container: {
    flex: 1,
  },
});

export default Payments;
