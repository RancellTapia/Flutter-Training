import React from "react";
import {
  ScrollView,
  StyleSheet,
  Dimensions,
  View,
  SafeAreaView,
} from "react-native";
//galio
import { Block, theme, Input, Button } from "galio-framework";

import PaymentCard from "../../components/Payment/PaymentCard";

class AddPayment extends React.Component {
  render() {
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <View>
            <PaymentCard />
          </View>
          <View
            style={styles.contentInput}
          >
            <Input
              placeholder="Country"
              color="black"
            />
            <Input
              placeholder="City"
              color="black"
            />
            <Input
              placeholder="Adress"
              color="black"
            />
          </View>
          <View style={styles.contentButton}>
            <Button color="success">Save</Button>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }
}
const styles = StyleSheet.create({
  contentInput: {
    padding: 15,
  },
  contentButton: {
    alignItems: "center"
  },
  container: {
    flex: 1,
  },

});

export default AddPayment;
