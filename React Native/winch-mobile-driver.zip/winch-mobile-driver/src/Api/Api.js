import ApiConfig from "../config/config";
import axios from "axios";
import AsyncStorage from '@react-native-community/async-storage';

// Create axios client, pre-configured with baseURL
let API = axios.create({
  baseURL: "http://3.15.45.186:4000/v1/",
});

// Set JSON Web Token in Client to be included in all calls
export const setClientToken = (token) => {
  API.interceptors.request.use(function (config) {
    config.headers.Authorization = `Bearer ${token}`;
    return config;
  });
};

export const StoreData = async (result) => {
  try {
     await AsyncStorage.setItem('@token', JSON.stringify(result.token));
     await AsyncStorage.setItem('@refreshToken',JSON.stringify( result.refreshToken));
     await AsyncStorage.setItem('@user', JSON.stringify( result.user));
  } catch (error) {
    // Error saving data
  }
};

export default API;
