import React, { useState, useEffect } from "react";
import { useSafeArea } from "react-native-safe-area-context";
import { ScrollView, StyleSheet, Image, ImageBackground } from "react-native";
import { Block, Text, theme } from "galio-framework";
import { argonTheme } from "../constants";
import { LinearGradient } from "expo-linear-gradient";

import Images from "../constants/Images";
import { DrawerItem as DrawerCustomItem } from "../components";
import { Dimensions } from "react-native";
import AsyncStorage, {
  useAsyncStorage,
} from "@react-native-community/async-storage";

function CustomDrawerContent({
  drawerPosition,
  navigation,
  profile,
  focused,
  state,
  ...rest
}) {
  const insets = useSafeArea();
  const [user, setUser] = useState({
    name: "",
    email: "",
  });
  const screens = ["Home", "Payments", "Truck", "History", "Configuration"];
  useEffect(() => {
    getData();
  });

  const getData = async () => {
    try {
      const value = await AsyncStorage.getItem("@user");

      if (value !== null) {
        setUser({
          ...user,
          name: JSON.parse(value).name,
          email: JSON.parse(value).email,
        });
      }
    } catch (e) {}
  };
  return (
    <Block
      style={styles.container}
      forceInset={{ top: "always", horizontal: "never" }}
    >
      <Block style={styles.header}>
        <ImageBackground source={Images.menuBackGround} style={styles.image}>
          <Image style={styles.tinyLogo} source={Images.avatarUser} />
          <Text color="#FFFFFF" size={24}>
            {user.name}
          </Text>
          <Text color="#FFFFFF" size={16}>
            {user.email}
          </Text>
        </ImageBackground>
      </Block>
      <Block flex style={{ paddingLeft: 8, paddingRight: 14 }}>
        <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
          {screens.map((item, index) => {
            return (
              <DrawerCustomItem
                title={item}
                key={index}
                navigation={navigation}
                focused={state.index === index ? true : false}
              />
            );
          })}
          <Block
            flex
            style={{ marginTop: 24, marginVertical: 8, paddingHorizontal: 8 }}
          >
            <Block
              style={{
                borderColor: "rgba(0,0,0,0.2)",
                width: "100%",
                borderWidth: StyleSheet.hairlineWidth,
              }}
            />
            <Text
              onPress={() => navigation.navigate("Onboarding")}
              color="#8898AA"
              style={{ marginTop: 16, marginLeft: 8 }}
            >
              Log Out
            </Text>
          </Block>
        </ScrollView>
      </Block>
    </Block>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    height: 200,
    paddingHorizontal: 0,
    justifyContent: "center",
    backgroundColor: "#000",
    marginBottom: 30,
    borderBottomWidth: 10,
    borderBottomColor: argonTheme.COLORS.DIVISOR,
  },
  image: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center",
    alignItems: "center",
    height: 190,
  },
});

export default CustomDrawerContent;
